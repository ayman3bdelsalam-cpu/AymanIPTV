package com.ayman.smartiptv.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.ayman.smartiptv.data.model.ContentType
import com.ayman.smartiptv.data.model.ResumeEntry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "ayman_iptv_prefs")

class PreferencesManager(private val context: Context) {

    private val gson = Gson()

    companion object {
        val KEY_HOST = stringPreferencesKey("host")
        val KEY_USER = stringPreferencesKey("user")
        val KEY_PASS = stringPreferencesKey("pass")
        val THIRTY_DAYS_MS = 30L * 24 * 60 * 60 * 1000
    }

    // ===== بيانات تسجيل الدخول =====
    suspend fun saveCredentials(host: String, user: String, pass: String) {
        try {
            context.dataStore.edit { prefs ->
                prefs[KEY_HOST] = host
                prefs[KEY_USER] = user
                prefs[KEY_PASS] = pass
            }
        } catch (e: Exception) {
            // فشل الحفظ لا يجب أن يوقف التطبيق — المستخدم فقط سيحتاج تسجيل الدخول يدويًا لاحقًا
        }
    }

    suspend fun clearCredentials() {
        try {
            context.dataStore.edit { it.clear() }
        } catch (e: Exception) { }
    }

    suspend fun getSavedHost(): String? = safeRead(KEY_HOST)
    suspend fun getSavedUser(): String? = safeRead(KEY_USER)
    suspend fun getSavedPass(): String? = safeRead(KEY_PASS)

    private suspend fun safeRead(key: Preferences.Key<String>): String? {
        return try {
            context.dataStore.data.map { it[key] }.first()
        } catch (e: Exception) {
            null
        }
    }

    private fun accountKey(host: String, user: String): String {
        val raw = "$host:$user"
        return raw.hashCode().toString()
    }

    // ===== المفضلة =====
    private fun favKey(host: String, user: String, type: ContentType) =
        stringPreferencesKey("favs_${accountKey(host, user)}_${type.name}")

    suspend fun getFavorites(host: String, user: String, type: ContentType): Set<Int> {
        return try {
            val raw = context.dataStore.data.map { it[favKey(host, user, type)] }.first()
            if (raw.isNullOrEmpty()) emptySet()
            else {
                val listType = object : TypeToken<List<Int>>() {}.type
                gson.fromJson<List<Int>>(raw, listType)?.toSet() ?: emptySet()
            }
        } catch (e: Exception) {
            emptySet()
        }
    }

    suspend fun toggleFavorite(host: String, user: String, type: ContentType, itemId: Int) {
        try {
            val current = getFavorites(host, user, type).toMutableSet()
            if (current.contains(itemId)) current.remove(itemId) else current.add(itemId)
            context.dataStore.edit { prefs ->
                prefs[favKey(host, user, type)] = gson.toJson(current.toList())
            }
        } catch (e: Exception) { }
    }

    // ===== نقاط استئناف المشاهدة =====
    private fun resumeKey(host: String, user: String) =
        stringPreferencesKey("resume_${accountKey(host, user)}")

    suspend fun getResumeMap(host: String, user: String): Map<String, ResumeEntry> {
        return try {
            val raw = context.dataStore.data.map { it[resumeKey(host, user)] }.first()
            if (raw.isNullOrEmpty()) emptyMap()
            else {
                val listType = object : TypeToken<List<ResumeEntry>>() {}.type
                val list: List<ResumeEntry> = gson.fromJson(raw, listType) ?: emptyList()
                val now = System.currentTimeMillis()
                list.filter { now - it.timestamp < THIRTY_DAYS_MS }
                    .associateBy { it.storageKey }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    suspend fun saveResumeEntry(host: String, user: String, entry: ResumeEntry) {
        try {
            val current = getResumeMap(host, user).toMutableMap()
            // اعتبر المشاهدة مكتملة إن اقتربت من النهاية — احذف نقطة الاستئناف
            if (entry.durationMs > 0 && entry.positionMs > entry.durationMs - 30_000) {
                current.remove(entry.storageKey)
            } else {
                current[entry.storageKey] = entry
            }
            context.dataStore.edit { prefs ->
                prefs[resumeKey(host, user)] = gson.toJson(current.values.toList())
            }
        } catch (e: Exception) { }
    }
}
