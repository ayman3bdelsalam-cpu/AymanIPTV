package com.ayman.smartiptv.ui.screens

import android.content.pm.ActivityInfo
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ayman.smartiptv.data.model.ContentType
import com.ayman.smartiptv.data.model.ResumeEntry
import com.ayman.smartiptv.ui.theme.*
import com.ayman.smartiptv.viewmodel.AppViewModel
import kotlinx.coroutines.delay

data class PlaybackTarget(
    val url: String,
    val title: String,
    val isSeekable: Boolean,
    val type: ContentType,
    val storageKey: String,
    val itemId: Int,
    val icon: String?,
    val ext: String,
    val startPositionMs: Long
)

@Composable
fun PlayerScreen(
    viewModel: AppViewModel,
    target: PlaybackTarget,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var isBuffering by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var reconnectAttempts by remember { mutableStateOf(0) }
    val maxReconnects = 3
    var isPlaying by remember { mutableStateOf(true) }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(target.url))
            if (target.startPositionMs > 0) seekTo(target.startPositionMs)
            prepare()
            playWhenReady = true
        }
    }

    // مستمع أحداث المشغّل — يعادل onplaying / onerror في نسخة الويب
    DisposableEffect(exoPlayer) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                when (state) {
                    Player.STATE_READY -> {
                        isBuffering = false
                        reconnectAttempts = 0
                        errorMessage = null
                    }
                    Player.STATE_BUFFERING -> isBuffering = true
                    Player.STATE_ENDED -> { /* انتهى العرض */ }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }

            override fun onPlayerError(error: PlaybackException) {
                // إعادة الاتصال التلقائي — نظير handleAutoReconnect في نسخة الويب
                if (reconnectAttempts < maxReconnects) {
                    reconnectAttempts++
                    errorMessage = "إعادة الاتصال ($reconnectAttempts/$maxReconnects)..."
                    exoPlayer.apply {
                        stop()
                        setMediaItem(MediaItem.fromUri(target.url))
                        prepare()
                        playWhenReady = true
                    }
                } else {
                    errorMessage = "تعذر تشغيل البث بعد عدة محاولات"
                    isBuffering = false
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose { exoPlayer.removeListener(listener) }
    }

    // إدارة دورة حياة الشاشة — إيقاف مؤقت عند مغادرة التطبيق
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> exoPlayer.pause()
                Lifecycle.Event.ON_RESUME -> if (isPlaying) exoPlayer.play()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // حفظ التقدم دوريًا كل 20 ثانية — نظير persistProgress في نسخة الويب
    LaunchedEffect(Unit) {
        while (true) {
            delay(20_000)
            if (target.type != ContentType.LIVE && exoPlayer.currentPosition > 10_000) {
                viewModel.saveResume(
                    ResumeEntry(
                        storageKey = target.storageKey,
                        name = target.title,
                        icon = target.icon,
                        positionMs = exoPlayer.currentPosition,
                        durationMs = exoPlayer.duration.coerceAtLeast(0),
                        timestamp = System.currentTimeMillis(),
                        type = target.type,
                        ext = target.ext,
                        itemId = target.itemId
                    )
                )
            }
        }
    }

    // تحرير الموارد عند الخروج من الشاشة
    DisposableEffect(Unit) {
        onDispose {
            if (target.type != ContentType.LIVE && exoPlayer.currentPosition > 10_000) {
                viewModel.saveResume(
                    ResumeEntry(
                        storageKey = target.storageKey,
                        name = target.title,
                        icon = target.icon,
                        positionMs = exoPlayer.currentPosition,
                        durationMs = exoPlayer.duration.coerceAtLeast(0),
                        timestamp = System.currentTimeMillis(),
                        type = target.type,
                        ext = target.ext,
                        itemId = target.itemId
                    )
                )
            }
            exoPlayer.release()
        }
    }

    BackHandler { onBack() }

    Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        AndroidView(
            factory = {
                PlayerView(context).apply {
                    player = exoPlayer
                    useController = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isBuffering) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = AccentBlue)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        errorMessage ?: "جارٍ الاتصال بالبث...",
                        color = AccentBlue, fontSize = 15.sp
                    )
                }
            }
        }

        if (errorMessage != null && reconnectAttempts >= maxReconnects) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(errorMessage!!, color = AccentRed, fontSize = 15.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = onBack) { Text("رجوع") }
                }
            }
        }

        IconButton(
            onClick = onBack,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(AccentRed, androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
        ) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "خروج", tint = androidx.compose.ui.graphics.Color.White)
        }
    }
}
